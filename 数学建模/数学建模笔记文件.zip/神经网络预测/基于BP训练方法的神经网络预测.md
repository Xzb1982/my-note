要了解神经网络是怎么预测数据的，首先要知道神经网络是怎么设计出来的
	在高中，我们看到问题，会经过我们的大脑（神经网络），得出我们认为的答案y帽，那么和真实答案y的差距被称作E
	根据这个误差，我们又经过神经网络优化我们的知识体系，然后再做一遍，直到误差为0或者无穷小为止。
	然后又面临一个问题，经神经网络之后，一对答案发现又有误差，那么我们就再优化，直到作对为止
	那么经过训练阶段，我们已经做好了准备；到了考试之后，我们就能够确保正确率了
	![[Pasted image 20260114151507.png]]
	于是这里诞生了两个问题，①神经网络是怎么算出来“我认为的答案”的；②神经网络是怎么通过误差E来调整自有的知识体系的架构的
	下面我们以最简单的神经网络结构来类比：
		![[Pasted image 20260114151838.png]]
		如果你学过生物，你就知道神经元传递信息是通过前一层的突触后膜，向下一层的突触前膜传递信号
		那么输入层就像我们的传感器官，例如我们被烫到了，产生电信号
		输出层就像我们的反应，被烫到了，于是我的手就收回去
		==**隐含层就是我大脑里面对输入的处理以及判断，还有之后发送信号给输出的过程==**
		**==我们将神经网络看作很多层，这些层里面有很多神经元==**
		**==如图，黑箭头是信号传递的过程，而每一层每一个神经元形成自己的一个处理，然后传递给下一个神经元**==
		如果经过很多个神经元，让结果足够精确，那么我们就能够预测数据
		更进一步地，每个神经元的处理流程是怎么样的呢?
			我们以全连接神经网络为例，将每个神经元拆分成这样：
			![[Pasted image 20260114152726.png]]
			我们有很多个来自第i个神经元的输入/来自感官的输入，一共n个
			而神经元在接受信息的过程中是有主次的，不像ADHD可能分不清主次
			那么就相当于赋权重一样，然后真正输入到神经元的信息有：$$\sum^n_{i=1} \omega_{i}x_{i}个信息$$
			但是每个神经元接收的信息都是有限的，于是我们用-阈值的方式来表示神经元：$$ \sum^n_{i=1} \omega_{i}x_{i} - \theta $$
			那么我的输出就是以上面这个表达式为自变量，输出函数的形式为：$$\begin{align*}
y = f(\sum^n_{i=1} \omega_{i}x_{i} - \theta)
\end{align*}$$
			![[Pasted image 20260114155556.png]]
			那么这个函数是什么呢？没有定论
			要么是线性函数，要么是阶跃函数，或sigmoid函数
			但问题来了，凭啥这里得到的值是0,1？因为在该模型中我们模拟的是大脑的电信号0,1；==**我们一般用的是sigmoid函数，因为连续才可导==**
			**==第二个原因是sigmoid函数求导后，可以简化计算**==
	下面我们来解决第二个问题，怎么通过误差来优化神经网络
		梯度下降法
			在解决第一个问题时，我们知道处理函数：$$\begin{align*}
y = f(\sum^n_{i=1} \omega_{i}x_{i} - \theta)
\end{align*}$$
			问题来了，已知xi,和我们选定的函数f()，要得到y，就要知道θ和权重是什么
			于是我们就知道了，确定一个神经网络的方式是通过y帽与真正答案y之间的误差E，根据E来优化调整权重和阈值
			![[Pasted image 20260114160723.png]]
			我们将整个网络调转过来，根据输出层神经元，假设只有一层隐含层
			$$\begin{align*}
定义训练集为：\{(x_{1},y_{1}),(x_{2},y_{2}),\dots,(x_{m},y_{m}) \},x_{i}\in R^d,y_{i} \in R^l\\
设神经网络的输出为 \hat{y_{k}} = (\hat{y}^k_{1},\hat{y}^k_{2},\dots ,\hat{y}^k_{l})\\
对单个输出的神经元我们有：\hat{y^k_{j}} = f\left( \sum^q_{h=1}\omega_{hj}b_{h} - \theta_{j} \right)
\end{align*}$$
			对于每一个案例：$$\begin{align*}
对于一个案例(x_{k},y_{k})我们有：均方误差MSE =E_{k} = \frac{1}{2} \sum^l_{j=1} (\hat{y^k_{j}} - y^k_{j})^2
\end{align*}$$
			这里的 1/2是为了方便求导，而且其实1/2，1/3，...不影响相对的误差
			那么对于每个权重和每个阈值，我们的更新估计式为:
			$$\omega +\Delta \omega \to \omega; \theta+ \Delta \theta \to \theta$$
			只要我们知道Delta 也就是更新的值，我们就知道更新之后的值了
			![[Pasted image 20260114163217.png]]
			==**我们优化的目标是让误差最小化，那么我们对误差进行泰勒展开**==
			假设我们已经完成了k轮的迭代，得到omega_k
			对于误差，我们有：$$E(\omega ) = E(\omega_{k}) + E'(\omega_{k})(\omega-\omega_{k}),此处忽略余项R$$
			那么在进行第k+1轮迭代时，我们有：$$令 \omega = \omega_{k+1},则E(\omega_{k+1} ) = E(\omega_{k}) + E'(\omega_{k})(\omega_{k+1}-\omega_{k}) $$
			那么有：$$E(\omega_{k+1} ) - E(\omega_{k}) = E'(\omega_{k})(\omega_{k+1}-\omega_{k})$$
			令误差足够小，则为：$$E(\omega_{k+1} ) - E(\omega_{k}) = E'(\omega_{k})(\omega_{k+1}-\omega_{k}) <0$$
			偏微分方程求出一个特解：$$\omega_{k+1} - \omega_{k} = - E'(\omega_{k})$$
			带入上式可得：$$E(\omega_{k+1} ) - E(\omega_{k}) = -[E'(\omega_{k})]^2 <0$$
			[[泰勒展开]]中提到，当x0,x离得很近的时候，可以忽略余项
			那么在这里就是omega_{k+1}和omega_{k}的距离很近，那么我们怎么表征这个“离得很近”呢？
			$$引入\eta >0来减小偏离程度，\eta被称为学习率,\omega_{k+1} - \omega_{k} = -\eta E'(\omega_{k})$$
			因为当η->0^+ 时，-η->0^- ,再带个常数E'(omega_k),仍然->0
			![[Pasted image 20260115223255.png]]
			让我们总结一下，Ek是我自认为的答案和真正的答案之间的误差
			那么输出神经元的输出和输入如上面两个式子，f是sigmoid函数
			之后我们因为已知输入和输出，要求出权重和阈值，那么我们写出参数更新估计式
			那么怎么从估计式得到我们想要的呢？通过误差得到迭代中真正的差距，我们可以得到：$$\begin{align*}
\Delta \omega_{hj} = -\eta E'(\omega_{hj}),即更新量 = 学习率*常数\\
进一步推导： \Delta \omega_{hj} = -\eta E'(\omega_{hj}) = -\eta \frac{\partial E_{k}}{\partial \omega_{hj}}\\
（这里用偏导数是因为有 \theta_{j}还有别的变量影响误差, E_{k} = \frac{1}{2} \sum^l_{j=1} (\hat{y^k_{j}} - y^k_{j})^2）
\end{align*}$$
			根据链式法则：$$\begin{align*}
\frac{\partial E_{k}}{\partial \omega_{hj}} = \frac{\partial E_{k}}{\partial \hat{y^k_{j}}} · \frac{\partial \hat{y^k_{j}}}{\partial \beta_{j}} · \frac{\partial \beta_{j}}{\partial \omega_{hj}}\\
代入原式= -\eta\frac{\partial E_{k}}{\partial \hat{y^k_{j}}} · \frac{\partial \hat{y^k_{j}}}{\partial \beta_{j}} · \frac{\partial \beta_{j}}{\partial \omega_{hj}}\\
从中取出一小段记作 g_{j} = -\frac{\partial E_{k}}{\partial \hat{y^k_{j}}} · \frac{\partial \hat{y^k_{j}}}{\partial \beta_{j}}\\
原式= -(\hat{y^k_{j}} - y^k_{j})·(\hat{y^k_{j}})'
\end{align*}$$
			因为激活函数f采用的是sigmoid函数：$$\begin{align*}
f(x) = \frac{1}{1+e^{-x}},那么有：(\hat{y^k_{j}})' = \hat{y^k_{j}}(1-\hat{y^k_{j}})\\
∵ sigmoid函数满足:f'(x) = f(x)(1-f(x)) \\
可以发现：\frac{\partial E_{k}}{\partial \hat{y^k_{j}}} · \frac{\partial \hat{y^k_{j}}}{\partial \beta_{j}} = (y^k_{j}- \hat{y^k_{j}} )·\hat{y^k_{j}}(1-\hat{y^k_{j}}) = g_{j}\\
又\because 由\beta的定义得到：\frac{\partial \beta_{j}}{\partial \omega_{hj}} = b_{h} \\
联立上述式子,得到:\\
\Delta \omega_{hj} = \eta g_{j}b_{h},类似的 \Delta \theta_{j} = - \eta g_{j}
\end{align*}$$
			那么我们可以观察，当学习率η越大，Delta omega_{hj}越大
			同时我们再来看g_j,当实际值和预测值差值变大，也就是你的答案和实际答案相差越大，你要调整的权重omega就越大
			而b_h作为输入值的量纲，量纲越大，调整的自然也越大
			那么回过头来，我们还要解释一下学习率η到底是什么？
				我们先要弄清楚我们的目标：让我们认为的答案和真实答案的差距最小化
				也就是误差最小化
				那么我们假设误差和权重之间存在某种关系：
				![[Pasted image 20260117201036.png]]
				即误差和omega之间存在一个最小值，使得误差最小
				当η太大的时候，当下降到最低点附近时，容易来回横跳：![[Pasted image 20260117201303.png]]
				陷入局部最优，而达不到那个最小值
				要么学习率很小，于是要花费的时间很长，从而到我要用模型了还不能训练出来
			那么我进一步往下一层递推
				![[Pasted image 20260117202104.png]]
				于是我知道了：每次学习率的迭代，会让权重和阈值调整，我的目标是让误差尽可能小
				这也是为什么我们需要算力，因为这让我们可以尽可能迭代得更多，从而让误差尽可能小



相关代码
	首先import numpy pandas
	还有from sklearn.preprocessing import StandardScaler（标准化模块）
	from sklearn.neural_network import MLPClassifier(分类器)
	from sklearn.metrics import accuracy_score(评价指标的计算方式) , classification_report, confusion_matrix
	当版本不同时可能会出现报错，那么我们会引入import warnings
	warning.filterwarnings('ignore')
	#加载数据
	df = pd.read_excel('数据集.xlsx')
	#转化为numpy数据
	data = df.values
	#设置训练集比例 train_ratio = 0.8
	train_size = int(np.floor(train_ratio* data.shape[0]))（训练集的大小就是用整个数据有多少行我就* 比例，再向下取整，最终得到一个整数值）
	#划分训练集与测试集 train1 = data[:train_size,:]
	x_train（训练集的定义） = train1[:,:-1]
		np的data函数中data[a,b,c....]各代表一个维度
		每个维度可以表示成`start:stop:step`
		在 numpy 里，`start:stop:step`，三个位置都可以省略。省略的含义是“用默认值”。
			默认规则是：
			- `start` 省略：从 0 开始
			- `stop` 省略：一直到这一维的末尾
			- `step` 省略：步长为 1
		train1 = data[:train_size,:]
			==第一维(行)写的是 `:train_size`，它只有一个冒号，所以它只表达了 `start` 和 `stop` 里的一部分，准确地说它等价于 `0:train_size:1`。==  
			也就是说：`start` 省略所以默认是 0，`stop` 是 `train_size`，`step` 省略所以默认是 1。这里根本没有写到 `step`。
			第二维（列）写 `:`，表示列从 0 到最后一列全都要
			==这里第二个冒号后面“什么都不写”，就是 `start` 和 `stop` 都省略了，含义是“所有列”。（也就是从0到这一列的末尾，步长为1）==
		x_train = train1[:,:-1]
			- 行写 `:`，表示所有行
			- 列写 `:-1`，表示==从第 0 列开始，一直到倒数第 1 列之前（也就是“去掉最后一列”）==  
			    这里 `-1` 是负索引，表示“最后一个位置”。==**切片的 `stop` 是“左闭右开”，也就是不包含 `stop` 本身，所以 `:-1` 会把最后一列排除掉。**==
	y_train =train1[:，-1].ravel()#最后一列为分类标签(输出数据的训练集)
		 `train1[:, -1]` 里，前面的 `:` 还是表示“所有行”。
		“，”后面的 `-1` 表示“最后一列”。所以这一句就是==**把训练集里每一行的最后一个字段取出来，作为分类标签 `y_train`。**==
		至于 `.ravel()` 的作用，它是把数组“压平成一维”。
			sklearn 的大多数分类器都希望 `y` 是一维形状，也就是 `shape = (n_samples,)`。如果你取出来的标签是二维形状 `shape = (n_samples, 1)`，模型有时会警告或报错，这时 `.ravel()` 就能把它变成一维。
	test1= data[train_size:,:]
	x_test = test1[:,:-1]
	y_test = test[:,-1].ravel()
	# 标准化
	scaler = StandardScaler()
	x_train_normalized = scaler.fit_transform(x_train)(这行代码的意思是用训练集数据，通过fit_transform得到一个归一化的值)
	x_test_normalized = scaler.transform(x_test)
		为什么测试集不用fit?
		==**因为 `fit` 这一步是在“学习标准化所需要的参数”，而这些参数必须只能从训练集里学出来，然后用同一套参数去变换训练集、测试集以及未来的新样本。**==
		如果你对测试集也 `fit`，等价于你在评估时“偷看了测试集的分布信息”。
	# 建立网络
		net = MLPClassifier(hidden_layer_sizes = (10,10,10)，activation = 'relu',solver = 'adam',max_iter = 2000,random_state = 42 ,verbose = True,early_stopping = True)(这里表示我们建立一个隐含层为3，每层10个神经元;激活函数为relu,优化器为adam,迭代上限2000次，学习种子42，学习种子是为了保证实验的可能性，设置训练可视化verbose，同时设置如果达到训练瓶颈就早停)
	# 训练网络
		net.fit(x_train_normalized,y_train)
	# 测试效果
		test_out = net.predict(x_train_normalized)
	# 统计预测效果
		num_error = np.sum(y_test != test_out)
		P_error = num_error/ len(test_out) (用错误的个数/总数)
		accuracy = 1-P_error
		print(f'错误率为：{round(P_error* 100)}')
		print(f'准确率为：{round(accuracy* 100)}')
		print(f'错误样本数为：{num_error}')
	# 计算混淆矩阵
		cm = confusion_matrix(y_test,test_out)
		混淆矩阵的作用是把“真实类别”和“预测类别”的对应关系，用一个计数表完整地摊开，让你不仅知道整体准确率是多少，还能看出模型到底把哪些类互相搞混了。